"use strict";
window["%namespace%"].state.play = {
	preload: function(){
		console.log("loading play state");
	},
	
	create: function(){
		console.log("starting play state");
	},
	
	update: function(){
		
	}
};