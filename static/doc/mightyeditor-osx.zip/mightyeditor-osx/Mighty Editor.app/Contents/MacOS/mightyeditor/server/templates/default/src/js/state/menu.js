"use strict";
window["%namespace%"].state.menu = {
	preload: function(){
		
	},
	
	create: function(){
		// you can create menu group in map editor and load it like this:
		// mt.create("menu");
	},
	
	update: function(){
		
	}
};