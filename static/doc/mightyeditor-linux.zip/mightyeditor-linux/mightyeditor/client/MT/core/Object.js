"use strict";
MT.require("core.mat");


MT(
	MT.core.MagicObject = function(data, game){
		this.game = game;
		this.data = data;
		this.matrix = [1, 0, 0, 1, 0, 0, 0, 0];
		
		
	},
	{
		move: function(x, y){
			
		}
	}
);