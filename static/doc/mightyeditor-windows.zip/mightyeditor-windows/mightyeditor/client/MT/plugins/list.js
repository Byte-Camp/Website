MT.plugins.list = 1;

MT.require("plugins.AssetManager");
MT.require("plugins.ObjectManager");
MT.require("plugins.MapEditor");
MT.require("plugins.Settings");
MT.require("plugins.Export");
MT.require("plugins.Import");
MT.require("plugins.Tools");
MT.require("plugins.UndoRedo");
MT.require("plugins.DataLink");
MT.require("plugins.Analytics");
